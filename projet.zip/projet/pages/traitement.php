<?php 

if(isset($_POST['nomDeFamille'])){

    $nom = htmlspecialchars($_POST['nomDeFamille']);
    $prenom = htmlspecialchars($_POST['prenom']);
    $ville = htmlspecialchars($_POST['ville']);

    include '../inc/cle.php';
    $sql = "INSERT INTO clients (nom, prenom, ville)
            VALUES ('$nom','$prenom','$ville')";

    $cle->query ($sql);

} else {
    header ('location: ../index.php');
}

