<?php include '../inc/header.php';?>

<main>

        <!-- <a href="../index.php">Accueil</a>
        <a href="liste.php">Liste</a>
        <a href="pages/contact.php"> Contact </a> -->

<h2> Liste des clients </h2>
<table>
<thead>
    <tr>
        <th> Nom </th>
        <th> Prénom </th>
        <th> Ville </th>
        <th> Supprimer </th>
        <th> Modifier </th>
    </tr>
</thead> 
<tbody>
<?php include '../inc/cle.php'; 

$sql = "SELECT * FROM clients";

$reponse = $cle->query($sql);

foreach($reponse AS $r): ?>

    <tr>
         <td> <?= $r['nom']?> </td>      
         <td> <?= $r['prenom']?> </td>      
         <td> <?= $r['ville']?> </td>
         <td>                   
            <form action="suppression.php" method="post">
                <input type="hidden" name="id" value=" <?= $r ['id'] ?>">
                <input type="image" src="../Image/red-cross-logo-vector-30-2970589213.jpg">
                </form>
         </td>

         <td> 
         <form action="modif.php" method="post">
                <input type="hidden" name="id" value=" <?= $r ['id'] ?>">
                <input type="image" src="../Image/dessin-stylo-bleu-stylo-rouge-bleu-bas_410516-87514-3512601598.jpg">
        </form>
         </td>
    </tr>   


<?php endforeach; ?>



</table>

</tbody>
</main>



<?php include '../inc/footer.php';?>