<?php  include '../inc/header.php'; ?>
<main>
<h2> 
            <a>
            <img src = "../Image/Lynix.fr-1.png" width ="30" alt="" > </a>

           
    </h2>

        <form action="traitement de donner.php" method="post" enctype="multipart/from-data">

            <label for = "lastname"> NOM</label>
            <input type= "texte" name="lastname" maxlength="200" id = "lastname">
            <br>

            <label for="Teo"> Prénom </label>
            <input id="Teo" type="text" name="firstname" maxlength="200">
            <br>

            <label for="adresse"> Adresse</label>
            <input id="adresse" type="text" name="adress" maxlength="249">
            <br>
            
            <label for="zip"> Code Postal</label>
            <input id="zip" type="text" name="zip" maxlength="10">
            <br>

            <label for="Town"> Ville </label>
            <input id="Town" type="text" name="Town" maxlength="249">
            <br>

            <label for="password"> Mot de Passe</label>
            <input id="password" type="text"  name="password" maxlength="200" minlength="4"> <!-- ou alors type="password" pour avoir les petit point -->
            <br> 

            <label for="cv"> Votre CV <img src="../efeejalt=""></label>
            <input type="file" name="cv" id="cv">
            <br>

            <label for="cb"> Numéro de CB</label>
            <input type="tel" name="cb" id="cb" maxlength="10">
            <br>

            <label for="nb"> Nespresso * 10 </label>
            <input id="nb" type="number" name="nb" max="1000" min="0" step="10">
            <br>
            
            <label for="email"> Votre email </label>
            <input id="email" type="email" name="email" maxlength="100" >
            <br>

            <label for="url"> Url internet (https obligatoire)</label>
            <input type="url" name="url" id="url" maxlength="200">

            <!-- ICI C'est fait expres le réinverssement de input et label-->

            <input type="radio" name="sex" id="mme" value="2">
            <label for="mme"> Mme</label>

            <input type="radio" name="sex" id="M" value="3">
            <label for="M"> M</label>

            <p> Quels sont vos 3 films préférés ?</p>
            <input type="checkbox" name="film" value="film0" id="film0">
            <label for="film0"> Inception </label>
            <br>

            <input type="checkbox" name="film" value="film1" id="film1">
            <label for="film1"> The Truman show </label>
            <br>

            <input type="checkbox" name="film" value="film2" id="film2">
            <label for="film2"> The Batman </label>
            <br>

            <input type="checkbox" name="film" value="film3" id="film3">
            <label for="film3"> Kingdom of Heaven </label>
            <br>

            <label for="pays"> Quel Pays ?</label>
            <select name="pays" id="pays">
                <option value="0"> autres </option>
                <option value="1"> Russie</option>
                <option value="2"> Bulgarie</option>
                <option value="3"> Arménie</option>
                <option value="4"> Serbie</option>
                <option value="5"> Suisse</option>
                <option value="33"> France</option>
            </select>
            <select name="couleur" required>
                <option disabled selected> Couleur préférée ? </option>
                <option value="color1"> Rouge</option>
                <option value="color2"> Bleu</option>
                <option value="color3"> Rose</option>
                <option value="color4"> Vert</option>
                <option value="color5"> Jaune</option>
                <option value="color6"> Noir</option>
                <option value="color7"> Blanc</option>
            </select>
            <select name="food" required>
                <option disabled selected> Quel est ta nourriture préférées ?</option>
            <optgroup label="Good and healthy food">
                <option value="food1"> Salade </option>
                <option value="food2"> Fruit</option>
                <option value="food3"> Pomme</option>
                <option value="food4"> Banane</option>
            </optgroup>

            <optgroup label="Reprend TOI !!! ">
                <option value="food5"> KFC</option>
                <option value="food6"> Burger King</option>
                <option value="food7"> McDo</option>
                <option value="food8"> O'Tacos</option>
            </optgroup>

        
            </select>

            <br>
            <br>
            <br>

            <label for="avis"> Votre avis nous intéresse (ou pas):</label>
            <br>
            <textarea name="avis" id="avis" cols="50" rows="15" maxlength="777"></textarea>
            <br>

            <!-- vraie possibilité pour valider-->
             <input type="submit" value="Valider votre commande ! ">
             <!-- Solution avec une image  -->
              
             <input type="search" id="recherche" maxlength="100" name="recherche" placeholder="Rechercher qqqchose...">
             <input type="image" src="valider.jpg" heigth="50" width="50">
             <!-- Fausse solution, mais qui marche. Le boutton sert normalement en dehors d'un form et on l'associe à du JavaScript-->
              <button> Valider votre commande !!! </button>

        </form>
</main>

        <?php include '../inc/footer.php';?>