<?php 

$id = $_POST ['id'];

include '../inc/cle.php';
$sql = "SELECT * FROM clients WHERE id=$id";

$reponse = $cle->query($sql);

foreach ($reponse AS $r): ?>

<form action="update.php" method="post">
        <input type="text" name="nomDeFamille" id="nom" value="<?= $r ['nom'] ?>" maxlength="200">
        <input type="text" name="prenom" id="prenom" value="<?= $r ['prenom'] ?>" maxlength="200">
        <input type="text" name="ville" id="ville" value="<?= $r ['ville'] ?>" maxlength="200">
        <input type="hidden" name="id" value="<?= $r['id']?>">
        <input type="submit" value="Modifier"> 
    </form>

<?php endforeach; ?>