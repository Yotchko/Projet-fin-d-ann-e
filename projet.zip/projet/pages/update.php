<?php

if(isset($_POST['nomDeFamille'])){

    $nom = htmlspecialchars ($_POST['nomDeFamille']);
    $prenom = htmlspecialchars ($_POST['prenom']);
    $ville = htmlspecialchars ($_POST['ville']);
    $id = htmlspecialchars ($_POST['id']);


include '../inc/cle.php';
$sql = "UPDATE clients
SET nom='$nom', prenom= '$prenom', ville= '$ville'
WHERE id=$id";

if($cle->query($sql)){
    header('Localisation:liste.php');
}

}