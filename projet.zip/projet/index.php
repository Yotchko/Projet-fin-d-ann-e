<?php
    include 'inc/header.php';
    ?>
    
<main>
    <h2>Accueil</h2>
        

    <form action="pages/traitement.php" method="post">
        <input type="text" name="nomDeFamille" id="nom" placeholder="Nom" maxlength="200">
        <input type="text" name="prenom" id="prenom" placeholder="Prénom" maxlength="200">
        <input type="text" name="ville" id="ville" placeholder="Ville" maxlength="200">
        <input type="submit" value="Valider votre inscription"> 
       
    </form>
</main>

<?php include 'inc/footer.php'; ?>