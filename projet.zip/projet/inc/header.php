<?php define('SOURCE', '/projet/'); ?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?= SOURCE ?>css/style.css">
    
    <title>Lynix</title>
</head>
<body>
    <header>
        <h1> Accueil <h1>
    </header>
    <nav>
        <a href="<?= SOURCE ?>index.php">Accueil</a>
        <a href="<?= SOURCE ?>pages/liste.php">Liste</a>
        <a href="<?= SOURCE ?>pages/contact.php"> Contact </a>
    </nav>
   