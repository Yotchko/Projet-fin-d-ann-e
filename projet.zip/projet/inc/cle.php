<?php 
define ('SERVEUR', 'mysql:server=localhost;dbname=project');
define('LOGIN', 'root');
define('MDP', '');


try{

$cle = new PDO(SERVEUR, LOGIN, MDP);

} catch(Exception $e) {

    echo $e->GetMessage();
}