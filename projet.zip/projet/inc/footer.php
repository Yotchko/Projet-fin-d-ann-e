    
    <aside>
        <P> ca c'est le aside </p>
    </aside> 

    <footer>
       <p> ca c'est footer <p> 
    </footer>
</body>
</html>