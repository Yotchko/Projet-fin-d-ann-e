CREATE DATABASE projet;
use projet;

CREATE table clients (
    id int AUTO_INCREMENT PRIMARY KEY,
    nom varchar(200),
    prenom varchar(200),
    ville varchar(200)
);
